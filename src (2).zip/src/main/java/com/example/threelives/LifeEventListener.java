package com.example.threelives;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.entity.Item;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerLoginEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.SkullMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.UUID;

public class LifeEventListener implements Listener {

    private final ThreeLivesSystem plugin;

    public LifeEventListener(ThreeLivesSystem plugin) {
        this.plugin = plugin;
    }

    @EventHandler(priority = EventPriority.MONITOR)
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        plugin.updatePlayerNameColor(player, plugin.getLives(player.getUniqueId()));
    }

    @EventHandler(priority = EventPriority.HIGHEST)
    public void onPlayerLogin(PlayerLoginEvent event) {
        UUID uuid = event.getPlayer().getUniqueId();
        if (plugin.isBanned(uuid)) {
            long remaining = plugin.getRemainingBanTicks(uuid);
            Component message;
            if (remaining == -1) {
                message = MiniMessage.miniMessage().deserialize("<dark_red><bold>PERMANENTLY ELIMINATED!</bold><red> Out of lives.");
            } else {
                message = MiniMessage.miniMessage().deserialize("<red>You are banned! Resurrecting in <yellow>" + remaining + "</yellow> server ticks.");
            }
            event.disallow(PlayerLoginEvent.Result.KICK_BANNED, message);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        UUID uuid = player.getUniqueId();
        Location deathLoc = player.getLocation();

        event.getDrops().clear();
        deathLoc.getWorld().playSound(deathLoc, Sound.ENTITY_WARDEN_SONIC_BOOM, 1.0f, 1.0f);

        ItemStack playerHead = new ItemStack(Material.PLAYER_HEAD);
        SkullMeta meta = (SkullMeta) playerHead.getItemMeta();
        if (meta != null) {
            meta.setOwningPlayer(player);
            meta.displayName(MiniMessage.miniMessage().deserialize("<red>" + player.getName() + "'s Head"));
            playerHead.setItemMeta(meta);
        }
        deathLoc.getWorld().dropItemNaturally(deathLoc, playerHead);

        int currentLives = plugin.getLives(uuid);
        currentLives--;
        plugin.setLives(uuid, currentLives);

        if (currentLives == 2 || currentLives == 1) {
            plugin.banPlayer(uuid, 960000L);
        } else if (currentLives <= 0) {
            plugin.permanentlyBanPlayer(uuid);
        }
    }

    @EventHandler(priority = EventPriority.MONITOR, ignoreCancelled = true)
    public void onItemDamage(EntityDamageEvent event) {
        if (!(event.getEntity() instanceof Item itemEntity)) return;

        ItemStack item = itemEntity.getItemStack();
        if (item.getItemMeta() == null) return;

        if (item.getItemMeta().getPersistentDataContainer().has(ThreeLivesSystem.LIFE_ITEM_KEY, PersistentDataType.BOOLEAN)) {
            String uuidStr = item.getItemMeta().getPersistentDataContainer().get(ThreeLivesSystem.OWNER_UUID_KEY, PersistentDataType.STRING);
            if (uuidStr == null) return;

            UUID ownerUUID = UUID.fromString(uuidStr);

            if (itemEntity.getHealth() - event.getFinalDamage() <= 0 || isCombustionDamage(event.getCause())) {
                executeLifeItemDestruction(ownerUUID);
                itemEntity.remove();
            }
        }
    }

    private boolean isCombustionDamage(EntityDamageEvent.DamageCause cause) {
        return cause == EntityDamageEvent.DamageCause.LAVA || 
               cause == EntityDamageEvent.DamageCause.FIRE || 
               cause == EntityDamageEvent.DamageCause.FIRE_TICK ||
               cause == EntityDamageEvent.DamageCause.BLOCK_EXPLOSION ||
               cause == EntityDamageEvent.DamageCause.ENTITY_EXPLOSION;
    }

    private void executeLifeItemDestruction(UUID ownerUUID) {
        int lives = plugin.getLives(ownerUUID);
        lives--;
        plugin.setLives(ownerUUID, lives);

        if (lives > 0) {
            plugin.banPlayer(ownerUUID, 960000L);
        } else {
            plugin.permanentlyBanPlayer(ownerUUID);
        }
    }
}