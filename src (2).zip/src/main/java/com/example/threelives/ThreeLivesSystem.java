package com.example.threelives;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public final class ThreeLivesSystem extends JavaPlugin {

    private File dataFile;
    private FileConfiguration dataConfig;
    private long totalServerTicks = 0;
    
    public static NamespacedKey LIFE_ITEM_KEY;
    public static NamespacedKey OWNER_UUID_KEY;

    @Override
    public void onEnable() {
        LIFE_ITEM_KEY = new NamespacedKey(this, "life_item");
        OWNER_UUID_KEY = new NamespacedKey(this, "owner_uuid");
        
        loadData();

        Bukkit.getScheduler().runTaskTimer(this, () -> {
            totalServerTicks++;
            if (totalServerTicks % 20 == 0) {
                checkTickUnbans();
            }
        }, 1L, 1L);

        Bukkit.getPluginManager().registerEvents(new LifeEventListener(this), this);

        LifeCommandExecutor commandExecutor = new LifeCommandExecutor(this);
        this.getCommand("lives").setExecutor(commandExecutor);
        this.getCommand("setlives").setExecutor(commandExecutor);
        this.getCommand("revive").setExecutor(commandExecutor);
        this.getCommand("givelife").setExecutor(commandExecutor);
    }

    @Override
    public void onDisable() {
        saveData();
    }

    private void loadData() {
        dataFile = new File(getDataFolder(), "data.yml");
        if (!dataFile.exists()) {
            dataFile.getParentFile().mkdirs();
            try {
                dataFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        dataConfig = YamlConfiguration.loadConfiguration(dataFile);
        totalServerTicks = dataConfig.getLong("global.ticks", 0L);
    }

    public void saveData() {
        dataConfig.set("global.ticks", totalServerTicks);
        try {
            dataConfig.save(dataFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public long getCurrentTicks() {
        return totalServerTicks;
    }

    public int getLives(UUID uuid) {
        return dataConfig.getInt("players." + uuid.toString() + ".lives", 3);
    }

    public void setLives(UUID uuid, int lives) {
        dataConfig.set("players." + uuid.toString() + ".lives", lives);
        saveData();
        
        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            updatePlayerNameColor(player, lives);
        }
    }

    public void banPlayer(UUID uuid, long durationTicks) {
        long unbanAt = totalServerTicks + durationTicks;
        dataConfig.set("players." + uuid.toString() + ".banned_until", unbanAt);
        saveData();

        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            Component kickMessage = MiniMessage.miniMessage().deserialize(
                    "<red>You have died! Unbanned in <yellow>" + (durationTicks / 20) + "</yellow> seconds (Server Ticks)."
            );
            player.kick(kickMessage);
        }
    }

    public void permanentlyBanPlayer(UUID uuid) {
        dataConfig.set("players." + uuid.toString() + ".banned_permanently", true);
        saveData();

        Player player = Bukkit.getPlayer(uuid);
        if (player != null) {
            Component kickMessage = MiniMessage.miniMessage().deserialize(
                    "<dark_red><bold>PERMANENTLY ELIMINATED!</bold>\n<red>You have lost all 3 lives."
            );
            player.kick(kickMessage);
        }
    }

    public boolean isBanned(UUID uuid) {
        if (dataConfig.getBoolean("players." + uuid.toString() + ".banned_permanently", false)) {
            return true;
        }
        long bannedUntil = dataConfig.getLong("players." + uuid.toString() + ".banned_until", 0L);
        return totalServerTicks < bannedUntil;
    }

    public long getRemainingBanTicks(UUID uuid) {
        if (dataConfig.getBoolean("players." + uuid.toString() + ".banned_permanently", false)) {
            return -1;
        }
        long bannedUntil = dataConfig.getLong("players." + uuid.toString() + ".banned_until", 0L);
        return Math.max(0, bannedUntil - totalServerTicks);
    }

    public void unban(UUID uuid) {
        dataConfig.set("players." + uuid.toString() + ".banned_permanently", false);
        dataConfig.set("players." + uuid.toString() + ".banned_until", 0L);
        saveData();
    }

    public void updatePlayerNameColor(Player player, int lives) {
        NamedTextColor color = switch (lives) {
            case 3 -> NamedTextColor.GREEN;
            case 2 -> NamedTextColor.YELLOW;
            case 1 -> NamedTextColor.RED;
            default -> NamedTextColor.DARK_GRAY;
        };
        player.displayName(Component.text(player.getName(), color));
        player.playerListName(Component.text(player.getName(), color));
    }

    private void checkTickUnbans() {
        if (dataConfig.getConfigurationSection("players") == null) return;

        for (String uuidStr : dataConfig.getConfigurationSection("players").getKeys(false)) {
            UUID uuid = UUID.fromString(uuidStr);
            if (dataConfig.getBoolean("players." + uuidStr + ".banned_permanently", false)) continue;

            long bannedUntil = dataConfig.getLong("players." + uuidStr + ".banned_until", 0L);
            if (bannedUntil > 0 && totalServerTicks >= bannedUntil) {
                dataConfig.set("players." + uuidStr + ".banned_until", 0L);
                saveData();
                getLogger().info("Player " + uuidStr + " has been auto-unbanned by server ticks elapsed.");
            }
        }
    }
}