package com.example.threelives;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.OfflinePlayer;
import org.bukkit.NamespacedKey;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import org.jetbrains.annotations.NotNull;

import java.util.List;
import java.util.UUID;

public class LifeCommandExecutor implements CommandExecutor {

    private final ThreeLivesSystem plugin;

    public LifeCommandExecutor(ThreeLivesSystem plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(@NotNull CommandSender sender, @NotNull Command cmd, @NotNull String label, @NotNull String[] args) {
        
        if (cmd.getName().equalsIgnoreCase("lives")) {
            if (args.length == 0) {
                if (!(sender instanceof Player player)) {
                    sender.sendMessage("Console must specify a player: /lives <player>");
                    return true;
                }
                int lives = plugin.getLives(player.getUniqueId());
                player.sendMessage(MiniMessage.miniMessage().deserialize("<green>You have <gold>" + lives + "</gold> lives remaining."));
                return true;
            } else {
                OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
                int lives = plugin.getLives(target.getUniqueId());
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<gold>" + target.getName() + "</gold> has <green>" + lives + "</green> lives."));
                return true;
            }
        }

        if (cmd.getName().equalsIgnoreCase("setlives")) {
            if (args.length < 2) {
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>Usage: /setlives <player> <amount>"));
                return true;
            }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
            try {
                int amount = Integer.parseInt(args[1]);
                plugin.setLives(target.getUniqueId(), amount);
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<green>Successfully set <gold>" + target.getName() + "'s</gold> lives to <aqua>" + amount + "</aqua>."));
            } catch (NumberFormatException e) {
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>Amount must be an integer!"));
            }
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("revive")) {
            if (args.length < 1) {
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>Usage: /revive <player>"));
                return true;
            }
            OfflinePlayer target = Bukkit.getOfflinePlayer(args[0]);
            if (!plugin.isBanned(target.getUniqueId())) {
                sender.sendMessage(MiniMessage.miniMessage().deserialize("<red>That player is not banned."));
                return true;
            }
            plugin.unban(target.getUniqueId());
            if (plugin.getLives(target.getUniqueId()) <= 0) {
                plugin.setLives(target.getUniqueId(), 1);
            }
            sender.sendMessage(MiniMessage.miniMessage().deserialize("<green>You have successfully revived <gold>" + target.getName() + "</gold>!"));
            return true;
        }

        if (cmd.getName().equalsIgnoreCase("givelife")) {
            if (!(sender instanceof Player giver)) {
                sender.sendMessage("Only players can give physical lives.");
                return true;
            }
            if (args.length < 1) {
                giver.sendMessage(MiniMessage.miniMessage().deserialize("<red>Usage: /givelife <player>"));
                return true;
            }

            Player receiver = Bukkit.getPlayer(args[0]);
            if (receiver == null || !receiver.isOnline()) {
                giver.sendMessage(MiniMessage.miniMessage().deserialize("<red>Target player must be online to accept a life item."));
                return true;
            }

            int giverLives = plugin.getLives(giver.getUniqueId());
            if (giverLives <= 1) {
                giver.sendMessage(MiniMessage.miniMessage().deserialize("<red>You don't have enough lives to trade! You must retain at least 1 life."));
                return true;
            }

            ItemStack lifeToken = new ItemStack(Material.NETHER_STAR);
            ItemMeta meta = lifeToken.getItemMeta();
            if (meta != null) {
                meta.displayName(MiniMessage.miniMessage().deserialize("<gold><bold>Bound Life Essence</bold>"));
                meta.lore(List.of(
                        MiniMessage.miniMessage().deserialize("<gray>Linked to: <yellow>" + giver.getName()),
                        MiniMessage.miniMessage().deserialize("<dark_purple>WARNING: If this item burns or is"),
                        MiniMessage.miniMessage().deserialize("<dark_purple>destroyed, <underlined>" + giver.getName() + "</underlined> loses a life!")
                ));

                meta.getPersistentDataContainer().set(ThreeLivesSystem.LIFE_ITEM_KEY, PersistentDataType.BOOLEAN, true);
                meta.getPersistentDataContainer().set(ThreeLivesSystem.OWNER_UUID_KEY, PersistentDataType.STRING, giver.getUniqueId().toString());
                meta.getPersistentDataContainer().set(new NamespacedKey(plugin, "salt"), PersistentDataType.STRING, UUID.randomUUID().toString());
                
                lifeToken.setItemMeta(meta);
            }

            plugin.setLives(giver.getUniqueId(), giverLives - 1);
            
            if (!receiver.getInventory().addItem(lifeToken).isEmpty()) {
                receiver.getLocation().getWorld().dropItemNaturally(receiver.getLocation(), lifeToken);
            }

            giver.sendMessage(MiniMessage.miniMessage().deserialize("<red>-1 Life</red>. Given as an essence crystal to <gold>" + receiver.getName() + "</gold>."));
            receiver.sendMessage(MiniMessage.miniMessage().deserialize("<green>Received a <gold>Bound Life Essence</gold> from <aqua>" + giver.getName() + "</aqua>! Protect it."));
            return true;
        }

        return false;
    }
}